"""Inline keyboards — glass-panel style menu layout (mirrors the design mockup)."""
from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from bot.config import (FILE_CATEGORIES, FILE_KINDS, IDEA_CATEGORIES,
                        PROJECT_STATUSES, PROJECT_TYPES, ROLE_DEFAULT_CATEGORY,
                        ROLES, SELF_ROLES, TASK_PRIORITIES, TASK_STATUSES)
from bot import texts

PAGE_SIZE = 8


def role_pick(owner: bool = False) -> InlineKeyboardMarkup:
    """Working roles are free to pick. Manager is a *request* (needs approval);
    'admin' is shown only to the owners listed in ADMIN_IDS."""
    btn = lambda key: InlineKeyboardButton(  # noqa: E731
        f"{ROLES[key]['emoji']} {ROLES[key]['label']}", callback_data=f"role:{key}")
    rows = [
        [btn("artist"), btn("producer")],
        [btn("designer")],
        [InlineKeyboardButton("🧑‍💼 درخواست نقش منیجر", callback_data="role:req")],
    ]
    if owner:
        rows.append([btn("admin")])
    return InlineKeyboardMarkup(rows)


def main_menu(has_role: bool = True, manager: bool = False,
              webapp_url: str | None = None, private: bool = False,
              my_tasks: int = 0) -> InlineKeyboardMarkup:
    """Home panel. Managers get the create/manage row; everyone else a clean menu."""
    tasks_label = f"🧩 تسک‌های من ({my_tasks})" if my_tasks else "🧩 تسک‌های من"
    rows = [
        [InlineKeyboardButton("📁 پروژه‌ها", callback_data="menu:projects"),
         InlineKeyboardButton(tasks_label, callback_data="menu:tasks")],
        [InlineKeyboardButton("🗂 فایل‌های پروژه", callback_data="menu:files"),
         InlineKeyboardButton("⬆️ آپلود سریع", callback_data="menu:upload")],
        [InlineKeyboardButton("⏰ ددلاین‌ها", callback_data="menu:deadlines"),
         InlineKeyboardButton("💡 ایده بگیر", callback_data="menu:ideas")],
        [InlineKeyboardButton("👥 تیم", callback_data="menu:team"),
         InlineKeyboardButton("📖 راهنما", callback_data="menu:help")],
    ]
    if manager:
        rows.append([InlineKeyboardButton("➕ پروژه جدید", callback_data="proj:new"),
                     InlineKeyboardButton("⚙️ مدیریت", callback_data="menu:admin")])
    if webapp_url:
        # web_app buttons are only valid in private chats; groups get a plain link
        web = (InlineKeyboardButton("🌐 داشبورد", web_app=WebAppInfo(url=webapp_url))
               if private else InlineKeyboardButton("🌐 داشبورد", url=webapp_url))
        rows.append([web])
    if not has_role:
        rows.insert(0, [InlineKeyboardButton("🎯 انتخاب نقش من", callback_data="menu:role")])
    return InlineKeyboardMarkup(rows)


def back(to: str = "menu:main") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton(texts.BACK, callback_data=to)]]
    )


def _page_nav(prefix: str, page: int, total: int, per: int = PAGE_SIZE) -> list:
    """◀️ 2/5 ▶️ row for any paginated list (empty when there is one page)."""
    pages = max(1, -(-total // per))
    if pages <= 1:
        return []
    row = []
    if page > 0:
        row.append(InlineKeyboardButton("◀️ قبلی", callback_data=f"{prefix}:{page - 1}"))
    row.append(InlineKeyboardButton(f"{page + 1}/{pages}", callback_data="noop"))
    if page < pages - 1:
        row.append(InlineKeyboardButton("بعدی ▶️", callback_data=f"{prefix}:{page + 1}"))
    return [row]


def projects_list(projects, page: int = 0, manager: bool = False) -> InlineKeyboardMarkup:
    rows = []
    for p in projects[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]:
        t = PROJECT_TYPES.get(p["ptype"], {"emoji": "📦"})
        s = PROJECT_STATUSES.get(p["status"], {"emoji": "❓"})
        label = f"{t['emoji']} {p['title']} · {s['emoji']}"
        rows.append([InlineKeyboardButton(label, callback_data=f"proj:view:{p['id']}")])
    rows += _page_nav("proj:pg", page, len(projects))
    if manager:
        rows.append([InlineKeyboardButton("➕ پروژه جدید", callback_data="proj:new")])
    rows.append([InlineKeyboardButton(texts.BACK, callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def project_detail(pid: int, is_manager: bool, file_total: int = 0) -> InlineKeyboardMarkup:
    files_label = f"🗂 فایل‌ها ({file_total})" if file_total else "🗂 فایل‌ها"
    rows = [
        [InlineKeyboardButton("📋 تسک‌ها", callback_data=f"task:list:{pid}"),
         InlineKeyboardButton(files_label, callback_data=f"pf:h:{pid}")],
        [InlineKeyboardButton("⬆️ آپلود فایل", callback_data=f"pf:u:{pid}")],
    ]
    if is_manager:
        rows[1].append(InlineKeyboardButton("➕ تسک جدید", callback_data=f"task:new:{pid}"))
        rows.append([
            InlineKeyboardButton("➡️ وضعیت بعدی", callback_data=f"proj:next:{pid}"),
            InlineKeyboardButton("📌 وضعیت…", callback_data=f"proj:status:{pid}"),
        ])
        rows.append([
            InlineKeyboardButton("✏️ ویرایش ددلاین", callback_data=f"proj:dl:{pid}"),
            InlineKeyboardButton("🗄 آرشیو", callback_data=f"proj:archive:{pid}"),
        ])
        rows.append([
            InlineKeyboardButton("🔁 یادآور معطل‌ها", callback_data=f"proj:nag:{pid}"),
        ])
    rows.append([InlineKeyboardButton(texts.BACK, callback_data="menu:projects")])
    return InlineKeyboardMarkup(rows)


def project_nag_pick(pid: int, current: int | None) -> InlineKeyboardMarkup:
    """proj:nagq:{pid}:{days} — cycle-nag cadence picker (0 = off)."""
    opts = [(1, "📆 هر روز"), (2, "⏳ هر ۲ روز"), (3, "⏳ هر ۳ روز"),
            (7, "🗓 هر هفته"), (0, "🔕 خاموش")]
    rows = []
    for i in range(0, len(opts), 2):
        row = []
        for d, label in opts[i:i + 2]:
            mark = " ✅" if current is not None and current == d else ""
            row.append(InlineKeyboardButton(label + mark, callback_data=f"proj:nagq:{pid}:{d}"))
        rows.append(row)
    rows.append([InlineKeyboardButton(texts.BACK, callback_data=f"proj:view:{pid}")])
    return InlineKeyboardMarkup(rows)

def project_status_pick(pid: int) -> InlineKeyboardMarkup:
    rows = []
    items = list(PROJECT_STATUSES.items())
    for i in range(0, len(items), 2):
        row = []
        for key, meta in items[i:i + 2]:
            row.append(InlineKeyboardButton(
                f"{meta['emoji']} {meta['label']}", callback_data=f"proj:set:{pid}:{key}"))
        rows.append(row)
    rows.append([InlineKeyboardButton(texts.BACK, callback_data=f"proj:view:{pid}")])
    return InlineKeyboardMarkup(rows)


def project_type_pick() -> InlineKeyboardMarkup:
    rows, items = [], list(PROJECT_TYPES.items())
    for i in range(0, len(items), 2):
        row = []
        for key, meta in items[i:i + 2]:
            row.append(InlineKeyboardButton(
                f"{meta['emoji']} {meta['label']}", callback_data=f"ptype:{key}"))
        rows.append(row)
    return InlineKeyboardMarkup(rows)


def deadline_pick(prefix: str = "dl", pid: int | None = None) -> InlineKeyboardMarkup:
    """Quick deadline buttons. With `pid` they target `{prefix}:{pid}:{val}`
    (used by the standalone deadline-edit flow); otherwise `{prefix}:{val}`."""
    def data(val: str) -> str:
        return f"{prefix}:{pid}:{val}" if pid is not None else f"{prefix}:{val}"

    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📅 ۳ روز", callback_data=data("3")),
            InlineKeyboardButton("📅 ۱ هفته", callback_data=data("7")),
        ],
        [
            InlineKeyboardButton("📅 ۲ هفته", callback_data=data("14")),
            InlineKeyboardButton("📅 ۱ ماه", callback_data=data("30")),
        ],
        [
            InlineKeyboardButton("✍️ تاریخ دستی", callback_data=data("manual")),
            InlineKeyboardButton("🚫 بدون ددلاین", callback_data=data("none")),
        ],
    ])


def tasks_list(tasks, prefix: str = "task:view") -> InlineKeyboardMarkup:
    rows = []
    for tk in tasks[:20]:
        ts = TASK_STATUSES.get(tk["status"], {"emoji": "❓"})
        label = f"{ts['emoji']} #{tk['id']} {tk['title'][:24]}"
        rows.append([InlineKeyboardButton(label, callback_data=f"{prefix}:{tk['id']}")])
    rows.append([InlineKeyboardButton(texts.BACK, callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def task_detail(tid: int, project_id: int, is_manager: bool) -> InlineKeyboardMarkup:
    rows = [[
        InlineKeyboardButton("✅ انجام شد", callback_data=f"task:st:{tid}:done"),
        InlineKeyboardButton("🔄 در حال انجام", callback_data=f"task:st:{tid}:doing"),
    ], [
        InlineKeyboardButton("🔍 بررسی", callback_data=f"task:st:{tid}:review"),
        InlineKeyboardButton("⏳ انتظار", callback_data=f"task:st:{tid}:pending"),
    ]]
    if is_manager:
        rows.append([InlineKeyboardButton("🗑 حذف تسک", callback_data=f"task:del:{tid}")])
    rows.append([InlineKeyboardButton(texts.BACK, callback_data=f"proj:view:{project_id}")])
    return InlineKeyboardMarkup(rows)


def task_assignee_pick(users, project_id: int) -> InlineKeyboardMarkup:
    rows = []
    for u in users:
        r = ROLES.get(u["role"] or "", {"emoji": "👤", "label": "—"})
        rows.append([InlineKeyboardButton(
            f"{r['emoji']} {u['full_name']}", callback_data=f"task:assign:{project_id}:{u['id']}")])
    return InlineKeyboardMarkup(rows)


def task_priority_pick(project_id: int) -> InlineKeyboardMarkup:
    rows = []
    items = list(TASK_PRIORITIES.items())
    for i in range(0, len(items), 2):
        row = []
        for key, meta in items[i:i + 2]:
            row.append(InlineKeyboardButton(
                f"{meta['emoji']} {meta['label']}",
                callback_data=f"task:prio:{project_id}:{key}"))
        rows.append(row)
    return InlineKeyboardMarkup(rows)


def ideas_menu() -> InlineKeyboardMarkup:
    rows, items = [], list(IDEA_CATEGORIES.items())
    for i in range(0, len(items), 2):
        row = []
        for key, meta in items[i:i + 2]:
            row.append(InlineKeyboardButton(
                f"{meta['emoji']} {meta['label']}", callback_data=f"idea:{key}"))
        rows.append(row)
    rows.append([InlineKeyboardButton("🧠 بریف کامل پروژه", callback_data="idea:full")])
    rows.append([InlineKeyboardButton(texts.BACK, callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def idea_again(category: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 یه ایده‌ی دیگه", callback_data=f"idea:{category}")],
        [InlineKeyboardButton("💡 بقیه‌ی دسته‌ها", callback_data="menu:ideas"),
         InlineKeyboardButton(texts.BACK, callback_data="menu:main")],
    ])


def idea_full_again() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 بریف جدید", callback_data="idea:full")],
        [InlineKeyboardButton(texts.BACK, callback_data="menu:main")],
    ])


def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 آمار کامل", callback_data="admin:stats"),
         InlineKeyboardButton("👥 مدیریت اعضا", callback_data="admin:members")],
        [InlineKeyboardButton("🗄 پروژه‌های آرشیو", callback_data="admin:archived"),
         InlineKeyboardButton("📣 اعلان همگانی", callback_data="admin:broadcast")],
        [InlineKeyboardButton("💾 بکاپ دیتابیس", callback_data="admin:backup"),
         InlineKeyboardButton("🧹 پاک‌سازی بورد", callback_data="admin:wipe")],
        [InlineKeyboardButton(texts.BACK, callback_data="menu:main")],
    ])


def wipe_confirm() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💾 اول بکاپ بگیر", callback_data="admin:backup"),
         InlineKeyboardButton("🧹 بله، پاک کن", callback_data="admin:wipe_go")],
        [InlineKeyboardButton(texts.BACK, callback_data="menu:admin")],
    ])


def reset_confirm() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🧨 بله، ریست کامل", callback_data="admin:reset_go"),
         InlineKeyboardButton("🙅 لغو", callback_data="admin:reset_no")],
    ])


def members_manage(users) -> InlineKeyboardMarkup:
    rows = []
    for u in users[:25]:
        r = ROLES.get(u["role"] or "", {"emoji": "👤", "label": "بدون نقش"})
        rows.append([InlineKeyboardButton(
            f"{r['emoji']} {u['full_name']}", callback_data=f"admin:user:{u['id']}")])
    rows.append([InlineKeyboardButton(texts.BACK, callback_data="menu:admin")])
    return InlineKeyboardMarkup(rows)


def member_role_pick(user_db_id: int) -> InlineKeyboardMarkup:
    rows = []
    items = list(ROLES.items())
    for i in range(0, len(items), 2):
        row = []
        for key, meta in items[i:i + 2]:
            row.append(InlineKeyboardButton(
                f"{meta['emoji']} {meta['label']}",
                callback_data=f"admin:setrole:{user_db_id}:{key}"))
        rows.append(row)
    rows.append([InlineKeyboardButton(texts.BACK, callback_data="admin:members")])
    return InlineKeyboardMarkup(rows)


def confirm_new_project() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ تأیید و ساخت", callback_data="proj:confirm")],
        [InlineKeyboardButton("❎ لغو", callback_data="proj:cancel")],
    ])


# =============================================================== project vault
def project_picker(projects, mode: str, counts: dict[int, int], page: int = 0) -> InlineKeyboardMarkup:
    """Pick a project before opening its vault (mode 'h') or uploading (mode 'u')."""
    rows = []
    for p in projects[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]:
        t = PROJECT_TYPES.get(p["ptype"], {"emoji": "📦"})
        n = counts.get(p["id"], 0)
        label = f"{t['emoji']} {p['title']}" + (f" · 🗂 {n}" if n else "")
        rows.append([InlineKeyboardButton(label, callback_data=f"pf:{mode}:{p['id']}")])
    rows += _page_nav(f"pf:pp:{mode}", page, len(projects))
    rows.append([InlineKeyboardButton("🏠 منوی اصلی", callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def vault_home(pid: int, counts: dict[str, int]) -> InlineKeyboardMarkup:
    rows, items = [], list(FILE_CATEGORIES.items())
    for i in range(0, len(items), 2):
        row = []
        for key, meta in items[i:i + 2]:
            n = counts.get(key, 0)
            row.append(InlineKeyboardButton(
                f"{meta['emoji']} {meta['label']}" + (f" ({n})" if n else ""),
                callback_data=f"pf:c:{pid}:{key}:0"))
        rows.append(row)
    rows.append([InlineKeyboardButton("⬆️ آپلود فایل", callback_data=f"pf:u:{pid}")])
    rows.append([InlineKeyboardButton("🔙 پروژه", callback_data=f"proj:view:{pid}"),
                 InlineKeyboardButton("🏠 منو", callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def vault_list(pid: int, cat: str, files, page: int, total: int) -> InlineKeyboardMarkup:
    rows = []
    for f in files:
        icon = FILE_KINDS.get(f["kind"], "📄")
        name = (f["title"] or f["file_name"] or f"فایل #{f['id']}")[:30]
        rows.append([InlineKeyboardButton(f"{icon} {name}", callback_data=f"pf:v:{f['id']}")])
    rows += _page_nav(f"pf:c:{pid}:{cat}", page, total)
    rows.append([InlineKeyboardButton("⬆️ آپلود تو این دسته", callback_data=f"pf:ua:{pid}:{cat}")])
    rows.append([InlineKeyboardButton("🔙 دسته‌ها", callback_data=f"pf:h:{pid}"),
                 InlineKeyboardButton("🏠 منو", callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def file_actions(fid: int, pid: int, cat: str, can_delete: bool) -> InlineKeyboardMarkup:
    row = [InlineKeyboardButton("🔙 لیست", callback_data=f"pf:c:{pid}:{cat}:0")]
    if can_delete:
        row.insert(0, InlineKeyboardButton("🗑 حذف", callback_data=f"pf:d:{fid}"))
    return InlineKeyboardMarkup([row])


def file_delete_confirm(fid: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("🗑 آره، حذف کن", callback_data=f"pf:dy:{fid}"),
        InlineKeyboardButton("↩️ نه", callback_data=f"pf:dn:{fid}"),
    ]])


def category_pick(action: str, pid: int, role: str | None = None,
                  suggested: str | None = None) -> InlineKeyboardMarkup:
    """Category picker. `action` is the callback prefix (pf:ua → upload, pf:sc → /save).
    The suggested category (file type, else the member's role) is starred and first."""
    suggested = suggested or ROLE_DEFAULT_CATEGORY.get(role or "")
    keys = list(FILE_CATEGORIES)
    if suggested in keys:
        keys.remove(suggested)
        keys.insert(0, suggested)
    rows, row = [], []
    for key in keys:
        meta = FILE_CATEGORIES[key]
        star = "⭐ " if key == suggested else ""
        row.append(InlineKeyboardButton(f"{star}{meta['emoji']} {meta['label']}",
                                        callback_data=f"{action}:{pid}:{key}"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"proj:view:{pid}")])
    return InlineKeyboardMarkup(rows)


def upload_active(pid: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ تمام شد", callback_data="pf:ue"),
        InlineKeyboardButton("🗂 دیدن فایل‌ها", callback_data=f"pf:h:{pid}"),
    ]])
