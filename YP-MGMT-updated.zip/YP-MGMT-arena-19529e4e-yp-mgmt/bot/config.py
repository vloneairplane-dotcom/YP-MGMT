"""Configuration loaded from environment / .env file."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS: set[int] = {
    int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x
}
NAG_DEFAULT_DAYS = max(0, int(os.getenv("REMIND_EVERY_DAYS", "3") or 0))  # cycle nag every N days; 0 = off
GROUP_CHAT_ID = int(os.getenv("GROUP_CHAT_ID") or 0) or None
# Render (and similar PaaS) inject PORT — honor it so the proxy can reach us
DASH_PORT = int(os.getenv("PORT") or os.getenv("DASH_PORT", "8000"))
DEMO_SEED = os.getenv("DEMO_SEED", "0").strip().lower() in {"1", "true", "yes"}

# Optional https URL of the dashboard → shown as a Telegram Mini App (menu button + panel button)
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip()
# Optional private channel/group: every uploaded file is also copied there as a durable backup
VAULT_CHAT_ID = int(os.getenv("VAULT_CHAT_ID") or 0) or None

DB_PATH = BASE_DIR / os.getenv("DB_PATH", "data/yp_mgmt.db")

# ---------- Roles ----------
ROLES = {
    "artist": {"label": "آرتیست", "emoji": "🎤"},
    "producer": {"label": "پرودیوسر", "emoji": "🎛️"},
    "designer": {"label": "دیزاینر", "emoji": "🎨"},
    "manager": {"label": "منیجر", "emoji": "🧑‍💼"},
    "admin": {"label": "ادمین", "emoji": "👑"},
}

# Who can manage projects / assign tasks
MANAGER_ROLES = {"manager", "admin"}

# Roles anybody may pick for themselves. Manager/admin are privileged:
#   admin   → only the owners listed in ADMIN_IDS (env) or granted by them
#   manager → by request, approved by a manager/admin (or set from the admin panel)
SELF_ROLES = ("artist", "producer", "designer")

# ---------- Project ----------
PROJECT_TYPES = {
    "beat": {"label": "بیت", "emoji": "🎹"},
    "demo": {"label": "دمو", "emoji": "🎙️"},
    "single": {"label": "سینگل", "emoji": "💿"},
    "ep": {"label": "ای‌پی / آلبوم", "emoji": "📀"},
    "cover": {"label": "کاور / عکاسی", "emoji": "📸"},
    "mv": {"label": "موزیک‌ویدیو", "emoji": "🎬"},
    "mix": {"label": "میکس / مستر", "emoji": "🎚️"},
    "other": {"label": "سایر", "emoji": "📦"},
}

PROJECT_STATUSES = {
    "idea": {"label": "ایده", "emoji": "💡"},
    "demo": {"label": "دمو", "emoji": "🎤"},
    "record": {"label": "ضبط", "emoji": "🎙️"},
    "mix": {"label": "میکس", "emoji": "🎛️"},
    "master": {"label": "مستر", "emoji": "🎚️"},
    "release": {"label": "ریلیز", "emoji": "🚀"},
    "done": {"label": "تمام‌شده", "emoji": "✅"},
}

STATUS_FLOW = ["idea", "demo", "record", "mix", "master", "release", "done"]

TASK_STATUSES = {
    "pending": {"label": "در انتظار", "emoji": "⏳"},
    "doing": {"label": "در حال انجام", "emoji": "🔄"},
    "review": {"label": "در حال بررسی", "emoji": "🔍"},
    "done": {"label": "انجام‌شده", "emoji": "✅"},
}

TASK_PRIORITIES = {
    "low": {"label": "کم", "emoji": "🟢"},
    "normal": {"label": "معمولی", "emoji": "🟡"},
    "high": {"label": "زیاد", "emoji": "🟠"},
    "urgent": {"label": "فوری", "emoji": "🔴"},
}

IDEA_CATEGORIES = {
    "concept": {"label": "کانسپت آهنگ", "emoji": "🎵"},
    "beat": {"label": "بیت و سبک", "emoji": "🎹"},
    "lyrics": {"label": "تم متن", "emoji": "📝"},
    "visual": {"label": "کاور و ویژوال", "emoji": "🎨"},
    "release": {"label": "استراتژی ریلیز", "emoji": "📣"},
    "collab": {"label": "کالب و همکاری", "emoji": "🤝"},
}

# ---------- Project vault (per-project file storage) ----------
# key → label/emoji. `kinds` is a hint used to pre-select a category from the file type.
FILE_CATEGORIES = {
    "beat": {"label": "بیت", "emoji": "🎹"},
    "vocal": {"label": "وکال و دمو", "emoji": "🎤"},
    "mix": {"label": "میکس و مستر", "emoji": "🎚️"},
    "cover": {"label": "کاور و ویژوال", "emoji": "🎨"},
    "video": {"label": "ویدیو", "emoji": "🎬"},
    "lyrics": {"label": "متن و نوت", "emoji": "📝"},
    "ref": {"label": "رفرنس", "emoji": "🔗"},
    "other": {"label": "سایر", "emoji": "📦"},
}

# Which category to suggest first for each role (shown with ⭐ in the picker)
ROLE_DEFAULT_CATEGORY = {
    "producer": "beat",
    "artist": "vocal",
    "designer": "cover",
}

FILE_KINDS = {
    "audio": "🎵",
    "voice": "🎙️",
    "document": "📄",
    "photo": "🖼️",
    "video": "🎬",
    "video_note": "⭕",
}
