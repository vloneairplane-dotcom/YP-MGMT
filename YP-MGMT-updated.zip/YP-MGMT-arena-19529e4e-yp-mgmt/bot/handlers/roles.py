"""Role registration — with a privilege boundary.

Anybody can pick a *working* role (artist / producer / designer).
Privileged roles can NOT be self-assigned:
  • admin   → only owners listed in ADMIN_IDS (they get it automatically)
  • manager → request flow: the member taps "request", managers/owners get an
              approve/deny message; the admin panel can also set it directly.
"""
from __future__ import annotations

import logging
import time

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from bot import config
from bot import database as db
from bot import keyboards as kb
from bot import texts
from bot.config import MANAGER_ROLES, ROLES, SELF_ROLES
from bot.utils import esc, is_main_admin, is_manager, user_of

logger = logging.getLogger("yp-mgmt")

REQUEST_COOLDOWN = 10 * 60  # seconds between two manager requests of the same member


def _request_keyboard(user_db_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ تأیید", callback_data=f"role:ok:{user_db_id}"),
        InlineKeyboardButton("❌ رد", callback_data=f"role:no:{user_db_id}"),
    ]])


async def role_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query:
        return
    user = user_of(update, context)
    parts = (query.data or "").split(":")
    action = parts[1] if len(parts) > 1 else ""
    if not user:
        await query.answer()
        return

    # ---- working roles: free choice
    if action in SELF_ROLES:
        db.set_role(user["tg_id"], action)
        db.log_activity(user["id"], "role", f"نقش {ROLES[action]['label']} انتخاب شد")
        await query.answer("✅ نقش ثبت شد")
        await query.edit_message_text(
            texts.role_set_text(action), reply_markup=kb.back("menu:main"))
        return

    # ---- privileged roles (also what old, stale buttons send: role:manager / role:admin)
    if action in MANAGER_ROLES:
        if user.get("role") == action:               # already has it — nothing to do
            await query.answer("✅ این نقش رو همین الان داری")
            return
        if action == "admin" and is_main_admin(user):  # owners may always take admin
            db.set_role(user["tg_id"], "admin")
            await query.answer("✅ نقش ادمین ثبت شد")
            await query.edit_message_text(
                texts.role_set_text("admin"), reply_markup=kb.back("menu:main"))
            return
        if action == "manager":
            await _request_manager(query, context, user)
            return
        await query.answer("⛔ نقش «ادمین» قابل انتخاب نیست؛ فقط ادمین اصلی می‌تونه بده",
                           show_alert=True)
        return

    if action == "req":
        await _request_manager(query, context, user)
        return

    # ---- approve / deny a manager request
    if action in {"ok", "no"} and len(parts) > 2:
        if not is_manager(user):
            await query.answer(texts.NO_PERMISSION, show_alert=True)
            return
        target = db.get_user_by_id(int(parts[2]))
        pending = context.bot_data.setdefault("role_requests", {})
        if not target:
            await query.answer("⚠️ عضو پیدا نشد")
            return
        pending.pop(target["tg_id"], None)
        who = esc(target["full_name"])
        if action == "ok":
            db.set_role(target["tg_id"], "manager")
            db.log_activity(user["id"], "admin", f"نقش منیجر برای {target['full_name']} تأیید شد")
            await query.answer("✅ تأیید شد")
            await query.edit_message_text(
                f"✅ نقش <b>منیجر</b> برای <b>{who}</b> تأیید شد (توسط {esc(user['full_name'])}).")
            note = "🎉 درخواست نقش منیجرت تأیید شد. /start رو بزن."
        else:
            await query.answer("رد شد")
            await query.edit_message_text(
                f"❌ درخواست منیجر <b>{who}</b> رد شد (توسط {esc(user['full_name'])}).")
            note = "درخواست نقش منیجرت تأیید نشد. می‌تونی با ادمین هماهنگ کنی."
        try:
            await context.bot.send_message(target["tg_id"], note)
        except Exception:  # noqa: BLE001 — the member may never have opened a DM
            if config.GROUP_CHAT_ID:
                try:
                    await context.bot.send_message(config.GROUP_CHAT_ID, f"{who}: {note}")
                except Exception:  # noqa: BLE001
                    pass
        return

    await query.answer()


async def _request_manager(query, context, user: dict) -> None:
    """Member asks for the manager role → owners/managers get approve/deny buttons."""
    if is_manager(user):
        await query.answer("✅ تو همین الان دسترسی مدیریتی داری")
        return
    pending = context.bot_data.setdefault("role_requests", {})
    last = pending.get(user["tg_id"], 0)
    if time.time() - last < REQUEST_COOLDOWN:
        await query.answer("⏳ درخواستت قبلاً رفته؛ منتظر تأیید ادمین باش", show_alert=True)
        return
    pending[user["tg_id"]] = time.time()

    text = (
        "🧑‍💼 <b>درخواست نقش منیجر</b>\n─────────────────────\n"
        f"👤 <b>{esc(user['full_name'])}</b>"
        + (f" (@{esc(user['username'])})" if user.get("username") else "") + "\n"
        f"🆔 <code>{user['tg_id']}</code>\n"
        "نقش منیجر یعنی ساخت پروژه/تسک، تغییر وضعیت و حذف. تأیید می‌کنی؟"
    )
    sent = 0
    for admin_id in config.ADMIN_IDS:
        try:
            await context.bot.send_message(admin_id, text,
                                           reply_markup=_request_keyboard(user["id"]))
            sent += 1
        except Exception:  # noqa: BLE001 — owner hasn't opened a DM with the bot yet
            logger.info("could not DM owner %s for role request", admin_id)
    if not sent and config.GROUP_CHAT_ID:
        # fallback: post in the team group — only managers' button presses count
        try:
            await context.bot.send_message(config.GROUP_CHAT_ID, text,
                                           reply_markup=_request_keyboard(user["id"]))
            sent += 1
        except Exception:  # noqa: BLE001
            pass
    if sent:
        await query.answer("📨 درخواستت برای ادمین‌ها رفت", show_alert=True)
    else:
        pending.pop(user["tg_id"], None)
        await query.answer("⚠️ نتونستم به ادمین‌ها خبر بدم؛ از ادمین بخواه نقشت رو بده",
                           show_alert=True)
