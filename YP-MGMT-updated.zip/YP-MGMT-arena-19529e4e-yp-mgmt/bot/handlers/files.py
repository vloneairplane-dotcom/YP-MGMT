"""Project vault — a fixed place for every project's files (beats, vocals, covers…).

Files are never downloaded to the server: we keep Telegram's own `file_id`
(plus metadata) in SQLite and re-send by id, so there is no disk usage and the
size limits are Telegram's, not the host's. Optionally every upload is also
copied into a private channel (`VAULT_CHAT_ID`) as an independent backup.

Callback map (all ≤ 64 bytes):
  pf:pp:{h|u}:{page}   project picker page          pf:h:{pid}        vault home
  pf:c:{pid}:{cat}:{n} category list, page n        pf:v:{fid}        send the file
  pf:d|dy|dn:{fid}     delete / confirm / cancel    pf:u:{pid}        pick category to upload
  pf:ua:{pid}:{cat}    arm upload mode              pf:ue             finish upload mode
  pf:sv:{pid}          /save → project chosen       pf:sc:{pid}:{cat} /save → save now
"""
from __future__ import annotations

import logging
import time

from telegram import Message, Update
from telegram.constants import ChatAction
from telegram.ext import ContextTypes

from bot import config, jdate
from bot import database as db
from bot import keyboards as kb
from bot import texts
from bot.config import FILE_CATEGORIES
from bot.utils import esc, is_manager, user_of

logger = logging.getLogger("yp-mgmt")

UPLOAD_TTL = 20 * 60          # upload mode switches itself off after 20 minutes
SAVE_TTL = 10 * 60            # a pending /save choice expires after 10 minutes


# ------------------------------------------------------------------ helpers
def extract_file(msg: Message | None) -> dict | None:
    """Normalise any file-carrying message into the fields we store (or None)."""
    if msg is None:
        return None
    caption = (msg.caption or "").strip()
    if msg.audio:
        a = msg.audio
        name = a.file_name or " - ".join(x for x in (a.performer, a.title) if x) or ""
        return dict(kind="audio", file_id=a.file_id, file_unique_id=a.file_unique_id,
                    file_name=name, mime=a.mime_type or "", size=a.file_size or 0,
                    duration=a.duration or 0, title=caption or a.title or "")
    if msg.voice:
        v = msg.voice
        return dict(kind="voice", file_id=v.file_id, file_unique_id=v.file_unique_id,
                    file_name="", mime=v.mime_type or "", size=v.file_size or 0,
                    duration=v.duration or 0, title=caption)
    if msg.video:
        v = msg.video
        return dict(kind="video", file_id=v.file_id, file_unique_id=v.file_unique_id,
                    file_name=v.file_name or "", mime=v.mime_type or "",
                    size=v.file_size or 0, duration=v.duration or 0, title=caption)
    if msg.video_note:
        v = msg.video_note
        return dict(kind="video_note", file_id=v.file_id, file_unique_id=v.file_unique_id,
                    file_name="", mime="", size=v.file_size or 0,
                    duration=v.duration or 0, title=caption)
    if msg.photo:
        ph = msg.photo[-1]  # biggest size
        return dict(kind="photo", file_id=ph.file_id, file_unique_id=ph.file_unique_id,
                    file_name="", mime="image/jpeg", size=ph.file_size or 0,
                    duration=0, title=caption)
    if msg.document:
        d = msg.document
        return dict(kind="document", file_id=d.file_id, file_unique_id=d.file_unique_id,
                    file_name=d.file_name or "", mime=d.mime_type or "",
                    size=d.file_size or 0, duration=0, title=caption)
    return None


def guess_category(kind: str, mime: str = "", name: str = "") -> str:
    """A sensible default category from the file type (the picker still lets you change it)."""
    mime, name = (mime or "").lower(), (name or "").lower()
    if kind == "photo" or mime.startswith("image/"):
        return "cover"
    if kind in {"video", "video_note"} or mime.startswith("video/"):
        return "video"
    if kind == "voice":
        return "vocal"
    if name.endswith((".txt", ".md", ".doc", ".docx", ".pdf")):
        return "lyrics"
    return "other"


def _thread_of(message) -> int | None:
    """Forum-topic id to reply into (None outside topics)."""
    if message is not None and getattr(message, "is_topic_message", False):
        return message.message_thread_id
    return None


def _pid_label(p) -> str:
    return esc(p["title"]) if p else "؟"


async def _vault_copy(context, msg: Message, p, cat: str, uploader: dict) -> int | None:
    """Optional independent backup: copy the file into VAULT_CHAT_ID. Never raises."""
    if not config.VAULT_CHAT_ID:
        return None
    meta = FILE_CATEGORIES.get(cat, {"label": cat, "emoji": "📦"})
    cap = (f"{meta['emoji']} {esc(p['title'])} › {meta['label']}\n"
           f"👤 {esc(uploader['full_name'])}")
    try:
        sent = await context.bot.copy_message(
            chat_id=config.VAULT_CHAT_ID, from_chat_id=msg.chat_id,
            message_id=msg.message_id, caption=cap)
        return sent.message_id
    except Exception as exc:  # noqa: BLE001 — a backup copy must never block the upload
        logger.warning("vault copy failed: %s", exc)
        return None


async def save_file(context, msg: Message, pid: int, cat: str, user: dict) -> str:
    """Store `msg`'s file in project `pid` under `cat`. Returns 'ok' | 'dup' | 'nofile' | 'noproject'."""
    info = extract_file(msg)
    if not info:
        return "nofile"
    p = db.get_project(pid)
    if not p or p["archived"]:
        return "noproject"
    if cat not in FILE_CATEGORIES:
        cat = "other"
    fid = db.add_file(pid, cat, uploaded_by=user["id"], **info)
    if fid is None:
        return "dup"
    vault_id = await _vault_copy(context, msg, p, cat, user)
    if vault_id:
        db.set_file_vault_msg(fid, vault_id)
    label = info["title"] or info["file_name"] or info["kind"]
    db.log_activity(user["id"], "file",
                    f"{FILE_CATEGORIES[cat]['label']} «{label[:40]}» → {p['title']}")
    return "ok"


# --------------------------------------------------------- project pickers
async def show_project_picker(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              mode: str, page: int = 0) -> None:
    """mode 'h' = open a project's vault, 'u' = quick upload."""
    projects = db.list_projects()
    title = {"h": "🗂 <b>فایل‌های کدوم پروژه؟</b>",
             "sv": "💾 <b>ذخیره توی کدوم پروژه؟</b>"}.get(mode, "⬆️ <b>آپلود توی کدوم پروژه؟</b>")
    if not projects:
        text = title + "\n─────────────────────\nهنوز پروژه‌ای نداریم. اول یه پروژه بساز."
        markup = kb.back("menu:main")
    else:
        counts = {p["id"]: db.count_files(p["id"]) for p in projects}
        text = title + "\n─────────────────────\nپروژه رو انتخاب کن 👇"
        markup = kb.project_picker(projects, mode, counts, page)
    query = update.callback_query
    if query:
        await query.edit_message_text(text, reply_markup=markup)
    elif update.effective_message:
        await update.effective_message.reply_text(text, reply_markup=markup)


async def cmd_files(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await show_project_picker(update, context, "h")


async def cmd_upload(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await show_project_picker(update, context, "u")


# -------------------------------------------------------------- the router
async def files_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query:
        return
    user = user_of(update, context)
    parts = (query.data or "").split(":")
    action = parts[1] if len(parts) > 1 else ""
    if not user:
        await query.answer()
        return

    try:
        if action == "pp":                                   # pf:pp:{mode}:{page}
            await query.answer()
            await show_project_picker(update, context, parts[2], int(parts[3]))
        elif action == "h":                                  # pf:h:{pid}
            await query.answer()
            await _vault_home(query, int(parts[2]))
        elif action == "c":                                  # pf:c:{pid}:{cat}:{page}
            await query.answer()
            await _vault_list(query, int(parts[2]), parts[3], int(parts[4]))
        elif action == "v":                                  # pf:v:{fid}
            await _send_file(query, context, user, int(parts[2]))
        elif action == "d":                                  # pf:d:{fid}  (ask)
            await _delete_ask(query, user, int(parts[2]))
        elif action == "dn":                                 # pf:dn:{fid} (cancel)
            await _delete_cancel(query, user, int(parts[2]))
        elif action == "dy":                                 # pf:dy:{fid} (confirm)
            await _delete_do(query, user, int(parts[2]))
        elif action == "u":                                  # pf:u:{pid}  pick category
            await query.answer()
            await _upload_pick_category(query, user, int(parts[2]))
        elif action == "ua":                                 # pf:ua:{pid}:{cat} arm
            await query.answer()
            await _upload_arm(query, context, int(parts[2]), parts[3])
        elif action == "ue":                                 # pf:ue finish
            await _upload_end(query, context)
        elif action == "sv":                                 # pf:sv:{pid} (/save)
            await query.answer()
            await _save_pick_category(query, context, user, int(parts[2]))
        elif action == "sc":                                 # pf:sc:{pid}:{cat} (/save)
            await _save_commit(query, context, user, int(parts[2]), parts[3])
        else:
            await query.answer()
    except (IndexError, ValueError):
        await query.answer("⚠️ دکمه نامعتبره — از منو دوباره شروع کن", show_alert=True)


# ------------------------------------------------------------- vault views
async def _vault_home(query, pid: int) -> None:
    p = db.get_project(pid)
    if not p:
        await query.edit_message_text("⚠️ پروژه پیدا نشد.", reply_markup=kb.back("menu:projects"))
        return
    counts = db.files_summary(pid)
    await query.edit_message_text(texts.vault_home_text(p, counts),
                                  reply_markup=kb.vault_home(pid, counts))


async def _vault_list(query, pid: int, cat: str, page: int) -> None:
    p = db.get_project(pid)
    if not p or cat not in FILE_CATEGORIES:
        await query.edit_message_text("⚠️ پیدا نشد.", reply_markup=kb.back("menu:projects"))
        return
    total = db.count_files(pid, cat)
    page = max(0, min(page, max(0, (total - 1) // kb.PAGE_SIZE)))
    files = db.list_files(pid, cat, limit=kb.PAGE_SIZE, offset=page * kb.PAGE_SIZE)
    await query.edit_message_text(
        texts.vault_list_text(p, cat, total, page, kb.PAGE_SIZE),
        reply_markup=kb.vault_list(pid, cat, files, page, total))


async def _send_file(query, context, user: dict, fid: int) -> None:
    f = db.get_file(fid)
    if not f:
        await query.answer("⚠️ این فایل دیگه وجود نداره", show_alert=True)
        return
    await query.answer("📤 دارم می‌فرستم…")
    msg = query.message
    chat_id = msg.chat.id
    thread = _thread_of(msg)
    can_delete = is_manager(user) or f["uploaded_by"] == user["id"]
    markup = kb.file_actions(fid, f["project_id"], f["category"], can_delete)
    caption = texts.file_caption(f)
    common = dict(chat_id=chat_id, reply_markup=markup, message_thread_id=thread)
    try:
        await context.bot.send_chat_action(chat_id, ChatAction.UPLOAD_DOCUMENT,
                                           message_thread_id=thread)
        kind = f["kind"]
        if kind == "audio":
            await context.bot.send_audio(audio=f["file_id"], caption=caption, **common)
        elif kind == "voice":
            await context.bot.send_voice(voice=f["file_id"], caption=caption, **common)
        elif kind == "photo":
            await context.bot.send_photo(photo=f["file_id"], caption=caption, **common)
        elif kind == "video":
            await context.bot.send_video(video=f["file_id"], caption=caption, **common)
        elif kind == "video_note":
            await context.bot.send_video_note(video_note=f["file_id"], **common)
        else:
            await context.bot.send_document(document=f["file_id"], caption=caption, **common)
    except Exception as exc:  # noqa: BLE001
        logger.warning("sending stored file %s failed: %s", fid, exc)
        await context.bot.send_message(
            chat_id, "⚠️ ارسال فایل نشد (شاید فایل از تلگرام پاک شده). "
                     "می‌تونی دوباره آپلودش کنی.", message_thread_id=thread)


# ---------------------------------------------------------------- deleting
def _can_delete(user: dict, f) -> bool:
    return bool(f) and (is_manager(user) or f["uploaded_by"] == user["id"])


async def _delete_ask(query, user: dict, fid: int) -> None:
    f = db.get_file(fid)
    if not _can_delete(user, f):
        await query.answer("⛔ فقط آپلودکننده یا منیجر می‌تونه حذف کنه", show_alert=True)
        return
    await query.answer("مطمئنی؟")
    await query.edit_message_reply_markup(reply_markup=kb.file_delete_confirm(fid))


async def _delete_cancel(query, user: dict, fid: int) -> None:
    f = db.get_file(fid)
    await query.answer("لغو شد")
    if f:
        await query.edit_message_reply_markup(reply_markup=kb.file_actions(
            fid, f["project_id"], f["category"], _can_delete(user, f)))


async def _delete_do(query, user: dict, fid: int) -> None:
    f = db.get_file(fid)
    if not _can_delete(user, f):
        await query.answer("⛔ فقط آپلودکننده یا منیجر می‌تونه حذف کنه", show_alert=True)
        return
    db.delete_file(fid)
    db.log_activity(user["id"], "file",
                    f"حذف «{(f['title'] or f['file_name'] or '#' + str(fid))[:40]}» از {f['project_title']}")
    await query.answer("🗑 حذف شد")
    try:
        await query.message.delete()
    except Exception:  # noqa: BLE001 — older than 48h in a group etc.
        await query.edit_message_reply_markup(reply_markup=None)


# --------------------------------------------------------------- uploading
async def _upload_pick_category(query, user: dict, pid: int) -> None:
    p = db.get_project(pid)
    if not p:
        await query.edit_message_text("⚠️ پروژه پیدا نشد.", reply_markup=kb.back("menu:projects"))
        return
    await query.edit_message_text(
        f"⬆️ <b>آپلود توی «{esc(p['title'])}»</b>\n─────────────────────\n"
        "این فایل‌ها از چه نوعیه؟ (⭐ = پیشنهاد برای نقش تو)",
        reply_markup=kb.category_pick("pf:ua", pid, user.get("role")))


async def _upload_arm(query, context, pid: int, cat: str) -> None:
    p = db.get_project(pid)
    if not p or cat not in FILE_CATEGORIES:
        await query.edit_message_text("⚠️ پیدا نشد.", reply_markup=kb.back("menu:projects"))
        return
    meta = FILE_CATEGORIES[cat]
    context.user_data["upload"] = {
        "pid": pid, "cat": cat, "chat_id": query.message.chat.id,
        "panel_id": query.message.message_id, "count": 0, "ts": time.time(),
    }
    tip = ("\n💡 عکس رو به‌صورت <b>File</b> بفرست تا کیفیتش افت نکنه."
           if cat == "cover" else "")
    await query.edit_message_text(
        f"📤 <b>آپلود فعال شد</b>\n─────────────────────\n"
        f"📁 {esc(p['title'])} › {meta['emoji']} {meta['label']}\n\n"
        "فایل‌ها رو همین‌جا بفرست — هر تعدادی که خواستی (آهنگ، عکس، ویدیو، فایل پروژه…).\n"
        "اگه کپشن بذاری، می‌شه اسم فایل توی لیست." + tip +
        "\nوقتی تموم شد «✅ تمام شد» رو بزن.",
        reply_markup=kb.upload_active(pid))


async def _upload_end(query, context) -> None:
    st = context.user_data.pop("upload", None)
    await query.answer("✅ تمام شد")
    if not st:
        await query.edit_message_text("📤 آپلودی فعال نبود.", reply_markup=kb.back("menu:main"))
        return
    p = db.get_project(st["pid"])
    meta = FILE_CATEGORIES.get(st["cat"], {"emoji": "📦", "label": st["cat"]})
    await query.edit_message_text(
        f"✅ <b>{jdate.fa_num(st['count'])} فایل ذخیره شد</b>\n"
        f"📁 {_pid_label(p)} › {meta['emoji']} {meta['label']}",
        reply_markup=kb.vault_home(st["pid"], db.files_summary(st["pid"])))


async def receive_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Group-1 handler: while upload mode is armed, store every file this member sends."""
    msg = update.effective_message
    st = context.user_data.get("upload")
    if not msg or not st:
        return
    if time.time() - st["ts"] > UPLOAD_TTL:
        context.user_data.pop("upload", None)
        return
    if msg.chat_id != st["chat_id"]:
        return
    user = user_of(update, context)
    if not user:
        return
    result = await save_file(context, msg, st["pid"], st["cat"], user)
    if result == "nofile":
        return
    if result == "noproject":
        context.user_data.pop("upload", None)
        await msg.reply_text("⚠️ این پروژه دیگه فعال نیست؛ آپلود بسته شد.")
        return
    if result == "ok":
        st["count"] += 1
        st["ts"] = time.time()
    # one quiet reaction per file instead of a chat full of replies
    try:
        await msg.set_reaction("👍" if result == "ok" else "🤝")
    except Exception:  # noqa: BLE001 — reactions disabled / no rights → short reply instead
        await msg.reply_text("✅ ذخیره شد" if result == "ok" else "ℹ️ این فایل قبلاً توی پروژه بود")
    if result == "ok":
        p = db.get_project(st["pid"])
        meta = FILE_CATEGORIES.get(st["cat"], {"emoji": "📦", "label": st["cat"]})
        try:  # keep the panel's counter live
            await context.bot.edit_message_text(
                f"📤 <b>آپلود فعال</b> — {jdate.fa_num(st['count'])} فایل ذخیره شد\n"
                f"─────────────────────\n📁 {_pid_label(p)} › {meta['emoji']} {meta['label']}\n"
                "فایل بعدی رو بفرست یا «✅ تمام شد» رو بزن.",
                chat_id=st["chat_id"], message_id=st["panel_id"],
                reply_markup=kb.upload_active(st["pid"]))
        except Exception:  # noqa: BLE001 — edit flood limits / message gone: harmless
            pass


# ------------------------------------------------------ /save (reply-to-file)
async def cmd_save(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Reply to any file with /save → pick project → pick category → stored."""
    msg = update.effective_message
    user = user_of(update, context)
    if not msg or not user:
        return
    target = msg.reply_to_message
    info = extract_file(target)
    if not info:
        await msg.reply_text(
            "📎 روی یه <b>فایل</b> (آهنگ، عکس، ویدیو، داکیومنت) ریپلای کن و بعد /save بزن.")
        return
    projects = db.list_projects()
    if not projects:
        await msg.reply_text("هنوز پروژه‌ای نداریم. اول یه پروژه بساز.")
        return
    # keep the Message object itself (in memory) — it carries file_id + ids for the vault copy
    context.user_data["pending_save"] = {"msg": target, "ts": time.time()}
    counts = {p["id"]: db.count_files(p["id"]) for p in projects}
    await msg.reply_text(
        "💾 <b>ذخیره‌ی فایل</b>\n─────────────────────\nتوی کدوم پروژه ذخیره بشه؟",
        reply_markup=kb.project_picker(projects, "sv", counts))


async def _save_pick_category(query, context, user: dict, pid: int) -> None:
    pend = context.user_data.get("pending_save")
    if not pend or time.time() - pend["ts"] > SAVE_TTL:
        context.user_data.pop("pending_save", None)
        await query.edit_message_text("⌛ این درخواست منقضی شده — دوباره روی فایل ریپلای کن و /save بزن.")
        return
    p = db.get_project(pid)
    if not p:
        await query.edit_message_text("⚠️ پروژه پیدا نشد.")
        return
    info = extract_file(pend["msg"]) or {}
    guess = guess_category(info.get("kind", ""), info.get("mime", ""), info.get("file_name", ""))
    await query.edit_message_text(
        f"💾 <b>ذخیره توی «{esc(p['title'])}»</b>\n─────────────────────\n"
        "توی کدوم دسته؟ (⭐ = پیشنهاد)",
        reply_markup=kb.category_pick("pf:sc", pid, user.get("role"),
                                      suggested=None if guess == "other" else guess))


async def _save_commit(query, context, user: dict, pid: int, cat: str) -> None:
    pend = context.user_data.get("pending_save")
    if not pend or time.time() - pend["ts"] > SAVE_TTL:
        context.user_data.pop("pending_save", None)
        await query.answer("⌛ منقضی شده — دوباره /save بزن", show_alert=True)
        return
    result = await save_file(context, pend["msg"], pid, cat, user)
    context.user_data.pop("pending_save", None)
    p = db.get_project(pid)
    meta = FILE_CATEGORIES.get(cat, {"emoji": "📦", "label": cat})
    if result == "ok":
        await query.answer("✅ ذخیره شد")
        text = f"✅ ذخیره شد\n📁 {_pid_label(p)} › {meta['emoji']} {meta['label']}"
    elif result == "dup":
        await query.answer("ℹ️ از قبل بود")
        text = f"ℹ️ این فایل قبلاً توی «{_pid_label(p)}» ذخیره شده بود."
    else:
        await query.answer("⚠️ ذخیره نشد", show_alert=True)
        return
    await query.edit_message_text(text, reply_markup=kb.vault_home(pid, db.files_summary(pid)))
