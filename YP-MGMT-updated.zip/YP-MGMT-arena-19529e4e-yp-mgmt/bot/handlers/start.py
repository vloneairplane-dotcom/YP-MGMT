"""Start / main menu / help handlers."""
from __future__ import annotations

from telegram import Update
from telegram.constants import ChatType
from telegram.ext import ContextTypes

from bot import config
from bot import database as db
from bot import jdate
from bot import keyboards as kb
from bot import texts
from bot.utils import deadline_badge, esc, is_main_admin, is_manager, role_badge, user_of


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = user_of(update, context)
    if not user or not update.effective_message:
        return
    first = user["full_name"].split(" ")[0]
    if not user.get("role"):
        await update.effective_message.reply_text(
            texts.WELCOME.format(name=esc(first), brand=texts.BRAND),
            reply_markup=kb.role_pick(owner=is_main_admin(user)),
        )
        return
    await show_main_menu(update, context)


def _focus_block(user: dict) -> tuple[str, int]:
    """Personal line(s) for the home panel: my open tasks + the nearest deadline."""
    mine = [t for t in db.list_tasks(assignee_id=user["id"]) if t["status"] != "done"]
    lines = []
    if mine:
        lines.append(f"🎯 تسک باز تو: <b>{jdate.fa_num(len(mine))}</b>\n")
    upcoming = [p for p in db.list_projects() if p["deadline"] and p["status"] != "done"]
    if upcoming:
        p = upcoming[0]  # list_projects() is already ordered by nearest deadline
        lines.append(f"⏰ نزدیک‌ترین ددلاین: <b>{esc(p['title'])}</b> — {deadline_badge(p['deadline'])}\n")
    return "".join(lines), len(mine)


async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE,
                         edit: bool = False) -> None:
    user = user_of(update, context)
    if not user:
        return
    s = db.stats()
    first = user["full_name"].split(" ")[0]
    focus, my_tasks = _focus_block(user)
    text = texts.MAIN_MENU.format(
        brand=texts.BRAND_FA, name=esc(first), role_badge=role_badge(user),
        projects=s["projects"], tasks=s["tasks"], tasks_done=s["tasks_done"],
        files=s["files"], focus=focus,
    )
    private = bool(update.effective_chat and update.effective_chat.type == ChatType.PRIVATE)
    markup = kb.main_menu(bool(user.get("role")), manager=is_manager(user),
                          webapp_url=config.WEBAPP_URL or None, private=private,
                          my_tasks=my_tasks)
    target = update.effective_message
    if edit and update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=markup)
    elif target:
        await target.reply_text(text, reply_markup=markup)


async def menu_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Route main-menu callback buttons."""
    query = update.callback_query
    if not query:
        return
    await query.answer()
    data = query.data or ""
    action = data.split(":")[1] if ":" in data else ""

    if action == "main":
        await show_main_menu(update, context, edit=True)
    elif action == "help":
        await query.edit_message_text(texts.HELP.format(brand=texts.BRAND_FA),
                                      reply_markup=kb.back())
    elif action == "role":
        user = user_of(update, context)
        name = esc(user["full_name"]) if user else "رفیق"
        await query.edit_message_text(
            texts.role_pick_text(name) + "\n\n" + texts.ROLES_DESC,
            reply_markup=kb.role_pick(owner=is_main_admin(user)),
        )
    elif action == "projects":
        from bot.handlers.projects import show_projects
        await show_projects(update, context, edit=True)
    elif action == "ideas":
        from bot.handlers.ideas import show_ideas_menu
        await show_ideas_menu(update, context, edit=True)
    elif action == "tasks":
        from bot.handlers.tasks import show_my_tasks
        await show_my_tasks(update, context, edit=True)
    elif action == "team":
        from bot.handlers.admin import show_team
        await show_team(update, context, edit=True)
    elif action == "deadlines":
        from bot.handlers.projects import show_deadlines
        await show_deadlines(update, context, edit=True)
    elif action == "files":
        from bot.handlers.files import show_project_picker
        await show_project_picker(update, context, "h")
    elif action == "upload":
        from bot.handlers.files import show_project_picker
        await show_project_picker(update, context, "u")
    elif action == "admin":
        from bot.handlers.admin import show_admin
        await show_admin(update, context, edit=True)
