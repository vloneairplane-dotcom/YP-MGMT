"""All user-facing Persian texts of the bot."""
from __future__ import annotations

from datetime import datetime

from bot import jdate
from bot.config import (FILE_CATEGORIES, IDEA_CATEGORIES, PROJECT_STATUSES,
                        PROJECT_TYPES, ROLES, TASK_PRIORITIES, TASK_STATUSES)
from bot.utils import date_disp, esc

MAX_TASKS_ON_CARD = 12
BRAND = "Ye Pesare · Management"
BRAND_FA = "یه پسر | پنل مدیریت تیم"

WELCOME = (
    "🪩 <b>{name}</b> خوش برگشتی به {brand}\n"
    "─────────────────────\n"
    "پنل مدیریت تیم، پروژه و تسک‌ها.\n"
    "نقشتو انتخاب کن تا وارد بشی 👇"
)

MAIN_MENU = (
    "🎛️ <b>{brand}</b>\n"
    "سلام {name} {role_badge}\n"
    "─────────────────────\n"
    "📊 پروژه‌ها: <b>{projects}</b>  |  ✅ تسک: <b>{tasks_done}/{tasks}</b>  |  🗂 فایل: <b>{files}</b>\n"
    "{focus}"
    "─────────────────────\n"
    "از منوی زیر یکی رو انتخاب کن 👇"
)

HELP = (
    "📖 <b>راهنمای {brand}</b>\n"
    "─────────────────────\n"
    "📁 <b>پروژه‌ها</b> — کارت هر پروژه: وضعیت، ددلاین، تسک‌ها و فایل‌ها\n"
    "🗂 <b>فایل‌های پروژه</b> — جای ثابت هر پروژه: بیت، وکال، کاور، میکس و…\n"
    "⬆️ <b>آپلود سریع</b> — پروژه و دسته رو انتخاب کن، بعد فایل‌ها رو بفرست\n"
    "🧩 <b>تسک‌های من</b> — تسک‌هات و تغییر وضعیتشون\n"
    "⏰ <b>ددلاین‌ها</b> · 💡 <b>ایده بگیر</b> · 👥 <b>تیم</b>\n"
    "─────────────────────\n"
    "⌨️ دستورها:\n"
    "/panel — منوی اصلی\n"
    "/projects — لیست پروژه‌ها\n"
    "/files — فایل‌های یه پروژه\n"
    "/upload — آپلود سریع\n"
    "/save — روی یه فایل <b>ریپلای</b> کن و بزن /save تا توی پروژه ذخیره بشه\n"
    "/tasks · /deadline · /team · /idea · /whoami\n"
    "🔐 دستورهای مدیر:\n"
    "/backup · /restore · /wipe · /reset_all\n"
    "─────────────────────\n"
    "💡 برای کاور، عکس رو به‌صورت <b>File</b> بفرست تا کیفیتش افت نکنه."
)


def role_pick_text(name: str) -> str:
    return (
        f"👤 <b>{name}</b> نقشت توی تیم چیه؟\n"
        "─────────────────────\n"
        "هر نقش دسترسی‌های خودش رو داره:"
    )


ROLES_DESC = (
    "🎤 <b>آرتیست</b> — اجرای وکال، ایده‌پردازی متن\n"
    "🎛️ <b>پرودیوسر</b> — بیت، میکس و مستر\n"
    "🎨 <b>دیزاینر</b> — کاور، ویژوال و محتوای بصری\n"
    "🧑‍💼 <b>منیجر</b> — مدیریت پروژه، تسک و ددلاین\n"
    "👑 <b>ادمین</b> — دسترسی کامل + مدیریت اعضا"
)


def role_set_text(role_key: str) -> str:
    r = ROLES[role_key]
    return f"✅ نقش تو ثبت شد: {r['emoji']} <b>{r['label']}</b>\nحالا از منوی اصلی شروع کن 👇"


PROJECT_LIST_HEADER = "📁 <b>پروژه‌ها:</b>\n─────────────────────"


def project_card_short(p) -> str:
    t = PROJECT_TYPES.get(p["ptype"], {"label": "?", "emoji": "📦"})
    s = PROJECT_STATUSES.get(p["status"], {"label": "?", "emoji": "❓"})
    dl = f"⏰ {date_disp(p['deadline'])}" if p["deadline"] else "⏰ بدون ددلاین"
    return (
        f"{t['emoji']} <b>{esc(p['title'])}</b>\n"
        f"   {s['emoji']} {s['label']}  |  {dl}"
    )


def files_line(counts: dict[str, int]) -> str:
    """'🎹 ۳ · 🎨 ۱' — compact per-category file counts for the project card."""
    parts = [f"{FILE_CATEGORIES[k]['emoji']} {jdate.fa_num(n)}"
             for k, n in counts.items() if n and k in FILE_CATEGORIES]
    return " · ".join(parts) if parts else "هنوز فایلی ذخیره نشده"


def project_detail(p, tasks, file_counts: dict[str, int] | None = None) -> str:
    """Project hub card. Long parts (description, task list) sit inside Telegram's
    expandable blockquote so the card stays short but nothing is hidden."""
    t = PROJECT_TYPES.get(p["ptype"], {"label": "?", "emoji": "📦"})
    s = PROJECT_STATUSES.get(p["status"], {"label": "?", "emoji": "❓"})
    desc = esc(p["description"]) or "—"
    lines = [
        f"{t['emoji']} <b>{esc(p['title'])}</b>  ·  {t['label']}",
        "─────────────────────",
        f"<blockquote expandable>{desc}</blockquote>",
        f"{s['emoji']} وضعیت: <b>{s['label']}</b>",
        f"⏰ ددلاین: <b>{date_disp(p['deadline'])}</b>",
    ]
    nag = p["nag_days"] if "nag_days" in p.keys() else None
    if nag is not None:
        extra = "🔕 خاموش" if nag == 0 else f"🔁 هر {jdate.fa_num(nag)} روز یادآوری"
        lines.append(f"⏱ {extra}")
    if file_counts is not None:
        lines.append(f"🗂 فایل‌ها: {files_line(file_counts)}")
    lines.append("─────────────────────")
    lines.append(f"📋 <b>تسک‌ها ({jdate.fa_num(len(tasks))}):</b>")
    if not tasks:
        lines.append("   — تسکی ثبت نشده")
    else:
        rows = []
        for tk in tasks[:MAX_TASKS_ON_CARD]:
            ts = TASK_STATUSES.get(tk["status"], {"label": "?", "emoji": "❓"})
            pr = TASK_PRIORITIES.get(tk["priority"], {"label": "?", "emoji": "🟡"})
            who = esc(tk["assignee_name"]) or "—"
            rows.append(
                f"{ts['emoji']} <b>#{tk['id']}</b> {esc(tk['title'])}\n"
                f"   👤 {who} | {pr['emoji']} {pr['label']} | ⏰ {date_disp(tk['deadline'])}"
            )
        if len(tasks) > MAX_TASKS_ON_CARD:
            rows.append(f"… و {jdate.fa_num(len(tasks) - MAX_TASKS_ON_CARD)} تسک دیگه (از «📋 تسک‌ها»)")
        lines.append("<blockquote expandable>" + "\n".join(rows) + "</blockquote>")
    return "\n".join(lines)


# ------------------------------------------------------------ project vault
def vault_home_text(p, counts: dict[str, int]) -> str:
    total = sum(counts.values())
    t = PROJECT_TYPES.get(p["ptype"], {"emoji": "📦"})
    lines = [
        f"🗂 <b>فایل‌های «{esc(p['title'])}»</b> {t['emoji']}",
        "─────────────────────",
    ]
    if total == 0:
        lines.append("هنوز چیزی ذخیره نشده. اولین فایل رو آپلود کن ⬆️")
    else:
        for key, meta in FILE_CATEGORIES.items():
            n = counts.get(key, 0)
            if n:
                lines.append(f"{meta['emoji']} {meta['label']}: <b>{jdate.fa_num(n)}</b>")
        lines.append(f"─────────────────────\nجمع: <b>{jdate.fa_num(total)}</b> فایل")
    lines.append("یه دسته رو بزن تا فایل‌هاش رو ببینی 👇")
    return "\n".join(lines)


def vault_list_text(p, cat: str, total: int, page: int, per: int) -> str:
    meta = FILE_CATEGORIES.get(cat, {"label": cat, "emoji": "📦"})
    lines = [f"{meta['emoji']} <b>{meta['label']}</b> — «{esc(p['title'])}»",
             "─────────────────────"]
    if total == 0:
        lines.append("این دسته هنوز خالیه.")
    else:
        pages = max(1, -(-total // per))
        lines.append(f"{jdate.fa_num(total)} فایل · صفحه {jdate.fa_num(page + 1)} از {jdate.fa_num(pages)}")
        lines.append("روی هر فایل بزن تا برات فرستاده بشه 👇")
    return "\n".join(lines)


def file_caption(f) -> str:
    """Caption sent together with a stored file."""
    meta = FILE_CATEGORIES.get(f["category"], {"label": f["category"], "emoji": "📦"})
    name = f["title"] or f["file_name"] or f"فایل #{f['id']}"
    return (
        f"{meta['emoji']} <b>{esc(name)}</b>\n"
        f"📁 {esc(f['project_title'])} › {meta['label']}\n"
        f"👤 {esc(f['uploader_name']) or '—'} · {fmt_dt(f['created_at'])}"
    )


def task_line(tk) -> str:
    ts = TASK_STATUSES.get(tk["status"], {"label": "?", "emoji": "❓"})
    pr = TASK_PRIORITIES.get(tk["priority"], {"label": "?", "emoji": "🟡"})
    return (
        f"{ts['emoji']} <b>#{tk['id']}</b> {esc(tk['title'])}\n"
        f"   📁 {esc(tk['project_title'])} | 👤 {esc(tk['assignee_name']) or '—'} | "
        f"{pr['emoji']} {pr['label']} | ⏰ {date_disp(tk['deadline'])}"
    )


def idea_card(category: str, text: str) -> str:
    meta = IDEA_CATEGORIES.get(category, {"label": "ایده", "emoji": "💡"})
    return (
        f"{meta['emoji']} <b>ایده — {meta['label']}</b>\n"
        "─────────────────────\n"
        f"{text}"
    )


def full_brief_text(brief: dict[str, str]) -> str:
    lines = ["🧠 <b>بریف کامل پروژه — از ایده تا ریلیز</b>", "─────────────────────"]
    for key, text in brief.items():
        emoji, label = "💡", key
        meta = IDEA_CATEGORIES.get(key)
        if meta:
            emoji, label = meta["emoji"], meta["label"]
        lines.append(f"{emoji} <b>{label}:</b>\n{text}")
    return "\n".join(lines)


TEAM_HEADER = "👥 <b>تیم یه پسر</b>\n─────────────────────"
STATS_HEADER = "📊 <b>آمار کلی</b>\n─────────────────────"
DEADLINE_HEADER = "⏰ <b>ددلاین‌های نزدیک</b>\n─────────────────────"
NOT_SET_ROLE = "⚠️ هنوز نقشت رو انتخاب نکردی — از منوی اصلی «نقش من» رو بزن."
NO_PERMISSION = "⛔ این بخش فقط برای منیجر/ادمین‌هاست."
CANCELLED = "❎ عملیات لغو شد."

GROUP_LOCK_DM = (
    "🔐 <b>این ربات فقط توی گروه کاری فعاله</b>\n"
    "─────────────────────\n"
    "اگه عضو تیمی: برو همین‌جا توی گروهت <code>/start</code> بزن 🚀\n"
    "اگه عضو تیم نیستی: اینجا جای تو نیست 🙂"
)
UNKNOWN = "🤔 متوجه نشدم — از دکمه‌های زیر استفاده کن."
BACK = "🔙 بازگشت"


def fmt_dt(iso: str | None) -> str:
    """ISO timestamp → '۱۴۰۵/۰۸/۰۶ — ۱۲:۳۱' (Jalali with Persian digits)."""
    if not iso:
        return "—"
    try:
        dt = datetime.fromisoformat(iso)
    except ValueError:
        return iso
    j = jdate.jalali_disp(dt.strftime("%Y-%m-%d"))
    if not j:
        return iso[:16].replace("T", " ")
    time_str = f"{dt.hour:02d}:{dt.minute:02d}".translate(jdate.FA_DIGITS)
    return f"{j} — {time_str}"
